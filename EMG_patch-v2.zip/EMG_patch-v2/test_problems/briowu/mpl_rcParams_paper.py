from matplotlib import pyplot as plt
import matplotlib as mpl

#mpl.rcParams['legend.framealpha'] = 0
#mpl.rcParams['legend.fontsize'] ='x-large'
#mpl.rcParams['xtick.labelsize'] = 'x-large' #'x-large' =14?
#mpl.rcParams['ytick.labelsize'] = 'x-large'
#mpl.rcParams['axes.labelsize'] = 16
##mpl.rcParams['image.cmap']= 'jet'
#mpl.rcParams['errorbar.capsize'] = 3
# mpl.rcParams['ps.fonttype']= 42
# mpl.rcParams['pdf.fonttype']= 42
# mpl.rcParams['figure.figsize']=[6.4,4.8]
# mpl.rcParams['figure.facecolor']=(1, 1, 1, 1) #set inline plots background not transparent
# mpl.rcParams['xtick.minor.visible'] = True
# mpl.rcParams['ytick.minor.visible'] = True


# def set_fonttype(fonttype):
#     '''
#     fonttype: 3 or 42 
#     '''
#     mpl.rcParams['ps.fonttype']= fonttype
#     mpl.rcParams['pdf.fonttype']= fonttype
# #mpl.rcParams['figure.dpi']=100
# #mpl.rcParams['xtick.major.size'] = 3.5
# #mpl.rcParams['ytick.major.size'] = 3.5

# #mpl.rcParams['axes.formatter.offset_threshold'] = 4
# #mpl.rcParams['axes.xmargin'] = 0.05
# #mpl.rcParams['axes.ymargin'] = 0.05

# # mpl.rcParams['text.latex.preamble'] = [
# #        ##r'\usepackage{siunitx}',   # i need upright \micro symbols, but you need...
# #        ##r'\sisetup{detect-all}',   # ...this to force siunitx to actually use your fonts
# #        r'\usepackage{DejaVuSans}',    # set the normal font here
# #        #r'\usepackage[scaled]{berasans}',
# #        #r'\usepackage[T1]{fontenc}',
# #        r'\usepackage{sansmath}',  # load up the sansmath so that math -> helvet
# #        r'\sansmath',               # <- tricky! -- gotta actually tell tex to use!
# #        #r'\usepackage{amsmath}'
# #        r'\mathchardef\mhyphen="2D'
       
# # ]
# tlp = ''
# tlp += r'\usepackage{DejaVuSans}'
# tlp += r'\usepackage{sansmath}'
# tlp += r'\sansmath'
# tlp += r'\mathchardef\mhyphen="2D'
# mpl.rcParams['text.latex.preamble'] = tlp



##fonts
mpl.rcParams[u'font.family']= ['Times New Roman']

mpl.rcParams[u'font.sans-serif']= ['Times New Roman',
                              'DejaVu Sans',
                              'Computer Modern Sans Serif',
                              'Lucida Grande',
                              'Verdana',
                              'Geneva',
                              'Lucid',
                              'Arial',
                              'Helvetica',
                              'Avant Garde',
                              'sans-serif']



mpl.rcParams['font.monospace']= ['Times New Roman',
                             'DejaVu Sans Mono',
                             'Computer Modern Typewriter',
                             'Andale Mono',
                             'Nimbus Mono L',
                             'Courier New',
                             'Courier',
                             'Fixed',
                             'Terminal',
                             'monospace']


mpl.rcParams['font.serif']= ['Times New Roman',
                         'DejaVu Serif',
                         'Computer Modern Roman',
                         'New Century Schoolbook',
                         'Century Schoolbook L',
                         'Utopia',
                         'ITC Bookman',
                         'Bookman',
                         'Nimbus Roman No9 L',
                         'Times New Roman',
                         'Times',
                         'Palatino',
                         'Charter',
                         'serif']



mpl.rcParams['mathtext.fontset'] = 'custom'
mpl.rcParams['mathtext.rm'] = 'Times New Roman'
mpl.rcParams['mathtext.it'] = 'Times New Roman:italic'
mpl.rcParams['mathtext.bf'] = 'Times New Roman:bold'
mpl.rcParams['mathtext.cal'] = 'cmsy10'
