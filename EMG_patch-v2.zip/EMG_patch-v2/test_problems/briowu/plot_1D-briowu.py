import numpy as np
import pandas 
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
import h5py
import math
import mpl_rcParams_paper
#matplotlib inline

R3 = h5py.File('./output/snapshot_002.hdf5')
R5 = np.loadtxt('./Exact/exact.txt')

pos3 = R3['PartType0']['Coordinates']
x3 = np.transpose(pos3)[0]
x3 = np.array(x3)
sort_x3 = np.argsort(x3)
x3 = x3[sort_x3]

PR5 = np.array(R5)
x5 = (PR5.T)[1]
rho5 = (PR5.T)[2]
P5 = (PR5.T)[3]
v0_5 = (PR5.T)[4]
v1_5 = (PR5.T)[5]
B0_5 = (PR5.T)[7]
B1_5 = (PR5.T)[8]





VFLD3 = R3['PartType0']['Velocities']
v0_3 = np.transpose(VFLD3)[0]
v0_3 = np.array(v0_3)
v0_3 = v0_3[sort_x3]
v1_3 = np.transpose(VFLD3)[1]
v1_3 = np.array(v1_3)
v1_3 = v1_3[sort_x3]

MFLD3 = R3['PartType0']['MagneticField']
B0_3 = np.transpose(MFLD3)[0]
B0_3 = np.array(B0_3)
B0_3 = B0_3[sort_x3]
B1_3 = np.transpose(MFLD3)[1]
B1_3 = np.array(B1_3)
B1_3 = B1_3[sort_x3]

RFLD3 = R3['PartType0']['Density']
rho3 = np.array(RFLD3)
rho3 = rho3[sort_x3]

EFLD3 = R3['PartType0']['InternalEnergy']
e3 = np.array(EFLD3)
e3 = e3[sort_x3]

e5=P5/rho5


P3 = rho3*e3
##########################################
divB3 = R3['PartType0']['DivergenceOfMagneticField']
divB3 = np.array(divB3)
divB3 = divB3[sort_x3]

h3 = R3['PartType0']['SmoothingLength'] 
h3 = np.array(h3)
h3 = h3[sort_x3]

B3 = B0_3*B0_3 + B1_3*B1_3



for j in range(len(x3)):
    divB3[j] = math.log10(h3[j]*abs(divB3[j])/math.sqrt(B3[j])+1.e-20)

##########################################

x = np.arange(1,10,0.01)
y = np.sin(x)
y1 = np.cos(x)
y2 = np.tan(x)
y3 = np.tanh(x)
y4 = np.sinh(x)
y5 = np.cosh(x)

#1 
fig = plt.figure(figsize=(33,16))

#2 
ax1 = fig.add_subplot(2,4,1) 
ax2 = fig.add_subplot(2,4,2)
ax3 = fig.add_subplot(2,4,3)
ax4 = fig.add_subplot(2,4,4)
ax5 = fig.add_subplot(2,4,5)
ax6 = fig.add_subplot(2,4,6)
ax7 = fig.add_subplot(2,4,7)
ax8 = fig.add_subplot(2,4,8)

ax1.set_aspect(1.65/1.1)
ax1.set_xlim(1.5,3.)
ax1.set_ylim(-0.4,0.7)
ax1.set_xticks(np.arange(1.6,2.9,0.2))
ax1.set_yticks(np.arange(-0.4,0.7,0.2))
xminorLocator1 = MultipleLocator(0.05)
yminorLocator1 = MultipleLocator(0.05)
ax1.xaxis.set_minor_locator(xminorLocator1)
ax1.yaxis.set_minor_locator(yminorLocator1)
ax1.tick_params(which='major', direction='in', labelsize=26, length=14, width=2)
ax1.tick_params(which='minor', direction='in', length=7, width=2)
ax1.spines['bottom'].set_linewidth(3)
ax1.spines['left'].set_linewidth(3)
ax1.spines['top'].set_linewidth(3)
ax1.spines['right'].set_linewidth(3)
ax1.plot(x3, v0_3, linewidth=3, color='red', label='GIZMO-EMG')
ax1.plot(x5, v0_5, linewidth=4, color='k', linestyle=':', label='Exact')
ax1.set_xlabel('$x$', fontproperties="Times New Roman", fontsize=34)
ax1.set_ylabel('$v^{1}$', fontproperties="Times New Roman", fontsize=34)

ax2.set_aspect(1.65/1.97)
ax2.set_xlim(1.5,3.)
ax2.set_ylim(-1.85,0.12)
ax2.set_xticks(np.arange(1.6,2.9,0.2))
ax2.set_yticks(np.arange(-1.5,0.12,0.5))
xminorLocator2 = MultipleLocator(0.05)
yminorLocator2 = MultipleLocator(0.1)
ax2.xaxis.set_minor_locator(xminorLocator2)
ax2.yaxis.set_minor_locator(yminorLocator2)
ax2.tick_params(which='major', direction='in', labelsize=26, length=14, width=2)
ax2.tick_params(which='minor', direction='in', length=7, width=2)
ax2.spines['bottom'].set_linewidth(3)
ax2.spines['left'].set_linewidth(3)
ax2.spines['top'].set_linewidth(3)
ax2.spines['right'].set_linewidth(3)
ax2.plot(x3, v1_3, linewidth=3, color='red', label='GIZMO-EMG')
ax2.plot(x5, v1_5, linewidth=4, color='k', linestyle=':', label='Exact')
ax2.set_xlabel('$x$', fontproperties="Times New Roman", fontsize=34)
ax2.set_ylabel('$v^{2}$', fontproperties="Times New Roman", fontsize=34)

ax3.set_aspect(1.65/0.17)
ax3.set_xlim(1.5,3.)
ax3.set_ylim(0.68,0.85)
ax3.set_xticks(np.arange(1.6,2.9,0.2))
ax3.set_yticks(np.arange(0.68,0.85,0.02))
xminorLocator3 = MultipleLocator(0.05)
yminorLocator3 = MultipleLocator(0.005)
ax3.xaxis.set_minor_locator(xminorLocator3)
ax3.yaxis.set_minor_locator(yminorLocator3)
ax3.tick_params(which='major', direction='in', labelsize=26, length=14, width=2)
ax3.tick_params(which='minor', direction='in', length=7, width=2)
ax3.spines['bottom'].set_linewidth(3)
ax3.spines['left'].set_linewidth(3)
ax3.spines['top'].set_linewidth(3)
ax3.spines['right'].set_linewidth(3)
ax3.plot(x3, B0_3, linewidth=3, color='red', label='GIZMO-EMG')
ax3.plot(x5, B0_5, linewidth=4, color='k', linestyle=':', label='Exact')
ax3.set_xlabel('$x$', fontproperties="Times New Roman", fontsize=34)
ax3.set_ylabel('$B^{1}$', fontsize=34, labelpad=9)
		
ax4.set_aspect(1.65/2.1)
ax4.set_xlim(1.5,3.)
ax4.set_ylim(-1.05,1.05)
ax4.set_xticks(np.arange(1.6,2.9,0.2))
ax4.set_yticks(np.arange(-1.0,1.05,0.5))
xminorLocator4 = MultipleLocator(0.05)
yminorLocator4 = MultipleLocator(0.1)
ax4.xaxis.set_minor_locator(xminorLocator4)
ax4.yaxis.set_minor_locator(yminorLocator4)
ax4.tick_params(which='major', direction='in', labelsize=26, length=14, width=2)
ax4.tick_params(which='minor', direction='in', length=7, width=2)
ax4.spines['bottom'].set_linewidth(3)
ax4.spines['left'].set_linewidth(3)
ax4.spines['top'].set_linewidth(3)
ax4.spines['right'].set_linewidth(3)
ax4.plot(x3, B1_3, linewidth=3, color='red', label='EMG')
ax4.plot(x5, B1_5, linewidth=4, color='k', linestyle=':', label='Exact')

ax4.legend(loc='upper right', prop={'family':'Times New Roman', 'size':30}, frameon=False)#, edgecolor='w')
ax4.set_xlabel('$x$', fontdict={'family':'Times New Roman', 'size':34})
ax4.set_ylabel('$B^{2}$', fontdict={'family':'Times New Roman', 'size':34}, labelpad=-1)

ax5.set_aspect(1.65/1.2)
ax5.set_xlim(1.5,3.0)
ax5.set_ylim(0.0,1.2)
ax5.set_xticks(np.arange(1.6,2.9,0.2))
ax5.set_yticks(np.arange(0.0,1.1,0.2))
xminorLocator5 = MultipleLocator(0.05)
yminorLocator5 = MultipleLocator(0.05)
ax5.xaxis.set_minor_locator(xminorLocator5)
ax5.yaxis.set_minor_locator(yminorLocator5)
ax5.tick_params(which='major', direction='in', labelsize=26, length=14, width=2)
ax5.tick_params(which='minor', direction='in', length=7, width=2)
ax5.spines['bottom'].set_linewidth(3)
ax5.spines['left'].set_linewidth(3)
ax5.spines['top'].set_linewidth(3)
ax5.spines['right'].set_linewidth(3)
ax5.plot(x3, rho3, linewidth=3, color='red', label='GIZMO-EMG')
ax5.plot(x5, rho5, linewidth=4, color='k', linestyle=':', label='Exact')
ax5.set_xlabel('$x$', fontproperties="Times New Roman", fontsize=34)
ax5.set_ylabel(r'$\rho$', fontsize=34, labelpad=25.5)

ax6.set_aspect(1.65/1.8)
ax6.set_xlim(1.5,3.)
ax6.set_ylim(0.6,2.4)
ax6.set_xticks(np.arange(1.6,2.9,0.2))
ax6.set_yticks(np.arange(1.0,2.4,0.5))
xminorLocator6  = MultipleLocator(0.05)
yminorLocator6  = MultipleLocator(0.1)
ax6.xaxis.set_minor_locator(xminorLocator6)
ax6.yaxis.set_minor_locator(yminorLocator6)
ax6.tick_params(which='major', direction='in', labelsize=26, length=14, width=2)
ax6.tick_params(which='minor', direction='in', length=7, width=2)
ax6.spines['bottom'].set_linewidth(3)
ax6.spines['left'].set_linewidth(3)
ax6.spines['top'].set_linewidth(3)
ax6.spines['right'].set_linewidth(3)
ax6.plot(x3, e3, linewidth=3, color='red', label='GZIMO-EMG')
ax6.plot(x5, e5, linewidth=4, color='k', linestyle=':', label='Exact')
ax6.set_xlabel('$x$', fontproperties="Times New Roman", fontsize=34)
ax6.set_ylabel('$u$', fontproperties="Times New Roman", fontsize=34, labelpad=25.5)

ax7.set_aspect(1.65/1.)
ax7.set_xlim(1.5,3.)
ax7.set_ylim(0.04,1.04)
ax7.set_xticks(np.arange(1.6,2.9,0.2))
ax7.set_yticks(np.arange(0.2,1.05,0.2))
xminorLocator7  = MultipleLocator(0.05)
yminorLocator7  = MultipleLocator(0.05)
ax7.xaxis.set_minor_locator(xminorLocator7)
ax7.yaxis.set_minor_locator(yminorLocator7)
ax7.tick_params(which='major', direction='in', labelsize=26, length=14, width=2)
ax7.tick_params(which='minor', direction='in', length=7, width=2)
ax7.spines['bottom'].set_linewidth(3)
ax7.spines['left'].set_linewidth(3)
ax7.spines['top'].set_linewidth(3)
ax7.spines['right'].set_linewidth(3)
ax7.plot(x3, P3, linewidth=3, color='red', label='GIZMO-EMG')
ax7.plot(x5, P5, linewidth=4, color='k', linestyle=':', label='Exact')
ax7.set_xlabel('$x$', fontproperties="Times New Roman", fontsize=34)
ax7.set_ylabel('$P_{\mathrm{gas}}$', fontproperties="Times New Roman", fontsize=34, labelpad=21)

ax8.set_aspect(1.65/7.)
ax8.set_xlim(1.5,3.)
ax8.set_ylim(-7,0)
ax8.set_xticks(np.arange(1.6,2.9,0.2))
ax8.set_yticks(np.arange(-7,0.1,1.))
xminorLocator8  = MultipleLocator(0.05)
yminorLocator8  = MultipleLocator(0.2)
ax8.xaxis.set_minor_locator(xminorLocator8)
ax8.yaxis.set_minor_locator(yminorLocator8)
ax8.tick_params(which='major', direction='in', labelsize=26, length=14, width=2)
ax8.tick_params(which='minor', direction='in', length=7, width=2)
ax8.spines['bottom'].set_linewidth(3)
ax8.spines['left'].set_linewidth(3)
ax8.spines['top'].set_linewidth(3)
ax8.spines['right'].set_linewidth(3)
ax8.set_xlabel('$x$', fontproperties="Times New Roman", fontsize=34)
ax8.set_ylabel(r'$\mathrm{log}_{10}(h|\nabla\cdot\mathbf{B}|/|\mathbf{B}|)$', fontproperties="Times New Roman", fontsize=34, labelpad=21)



fig.savefig('fig-briowu_ncl.png', bbox_inches='tight',dpi=fig.dpi)#, bbox_inches='tight',dpi=fig.dpi,pad_inches=0.0)
